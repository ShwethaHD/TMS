package com.tms.dao;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;

public interface ITraineeDAO {

	public int addTrainee(TraineeBean bean)throws TraineeException;
}
