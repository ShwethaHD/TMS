package com.tms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;

@Repository
@Transactional
public class TraineeDAOImpl implements ITraineeDAO {

	@PersistenceContext
	public EntityManager entityManager;
	
	@Override
	public int addTrainee(TraineeBean bean)throws TraineeException {
	int id=0;
		try {
			entityManager.persist(bean);
			entityManager.flush();
			id=bean.getTraineeId();
		} catch (Exception e) {
			throw new TraineeException("Unable to add new Trainee");
		}
		return id;
	}

}
