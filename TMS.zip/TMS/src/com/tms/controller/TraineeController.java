package com.tms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;
import com.tms.service.ITraineeService;


@Controller
public class TraineeController {

	@Autowired
	private ITraineeService traineeService;
	


	@RequestMapping("show")
	public String startPage(){
		
		return ("index");
	}

	/*@RequestMapping("register")
	public String insertEmp(){
		
		return "register";
	}*/
	
	
	@RequestMapping(value="addTrainee",method=RequestMethod.POST)
	public ModelAndView addTrinee(@ModelAttribute ("trainee") TraineeBean bean, BindingResult result) {
		
		ModelAndView mv=new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		}
		else
		{
			try {
				int id = traineeService.addTrainee(bean);
				mv.setViewName("success");
				/*mv.addObject("id", id);*/
				mv.addObject("trainee", bean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		
		
	}
		return(mv);
	
}}
