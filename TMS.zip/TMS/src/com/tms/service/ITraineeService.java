package com.tms.service;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;

public interface ITraineeService {

	public int addTrainee(TraineeBean bean)throws TraineeException;
	
	}