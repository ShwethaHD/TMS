package com.tms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.bean.TraineeBean;
import com.tms.dao.ITraineeDAO;
import com.tms.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	private ITraineeDAO traineeDAO;

	@Override
	public int addTrainee(TraineeBean bean) throws TraineeException {
		return traineeDAO.addTrainee(bean);
		
	}

}
