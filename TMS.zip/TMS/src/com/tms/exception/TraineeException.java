package com.tms.exception;

public class TraineeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6015030486797984177L;
	
	public TraineeException(String message){
		super(message);
		
	}

}
